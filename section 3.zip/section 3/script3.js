function sayHello(name,place){
    //body of the function
    console.log('Hello world ' + name + 'from' + place);
    let template = `
        <h2>Hello world ${name} from <span class="place"> ${place}</span></h2>
    `;
    return template;
}

document.write(sayHello('Kevin ', ' USA'));
document.write(sayHello('John' , 'USA'));
document.write(sayHello('Jessica', 'USA'));