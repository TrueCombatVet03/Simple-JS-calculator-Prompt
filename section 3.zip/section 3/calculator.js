function calculate(){
    console.log("Calculator function");
    let num1=Number(prompt("Enter the number 1:"));
    console.log(num1);
    let num2=Number(prompt("Enter the number 2:"));
    console.log(num2);
    let sum;
    sum=num1 + num2;
    let sub;
    sub=num1 - num2;
    let mult;
    mult=num1 * num2;
    let div;
    div=num1 / num2;

    
    console.log(sum);
    console.log(sub);
    console.log(mult);
    console.log(div);

    document.getElementById("results").innerHTML=`<p>${num1} + ${num2} = ${sum}</p>
    <p>${num1} - ${num2} = ${sub}</P>
    <p>${num1} * ${num2} = ${mult}</p>
    <p>${num1} / ${num2} = ${div}</p>
    `;

    
    //display the sum
    //display the subs
    //display the mult
    //display the division
}

