document.getElementById("myButton").onclick = function(){
    let productname = document.getElementById("productname").value;
    console.log("Product",productname);
}
document.getElementById("myButton2").onclick = function(){
    let quanity = document.getElementById("quanity").value;
    console.log("Quanity",quanity);
}
document.getElementById("myButton3").onclick = function (add){let price=
    document.getElementById("price").value;
    console.log("Price",price);
    
}

